from pca import PCA
from ica import ICA
from nmf import NMF
from lle import LLE
from identity import identity
