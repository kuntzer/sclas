__all__ = ['classifier', 'diagnostics', 'encoder', 'plots']

import utils
import plots

import image
import encoder
import classifier
import method
import diagnostics
from run import SClas
